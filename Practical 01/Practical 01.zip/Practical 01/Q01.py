
import sys

version=sys.version

print("Python Version:",version)
