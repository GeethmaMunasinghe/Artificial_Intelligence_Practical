
from datetime import datetime

#Get current date and time
now=datetime.now()

print("Current date and time: ", now.strftime("%m/%d/%Y %H:%M:%S"))


