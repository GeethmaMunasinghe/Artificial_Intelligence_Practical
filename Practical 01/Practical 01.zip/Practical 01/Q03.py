
string=input("Enter a string: ")

length=len(string)

print(length)