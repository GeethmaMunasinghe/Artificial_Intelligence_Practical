
def remove_odd_idx_chars(s):
    return s[::2]

string=input("Enter the string: ")
print("Output: ",remove_odd_idx_chars(string))
