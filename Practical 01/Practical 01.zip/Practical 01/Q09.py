
num=float(input("Enter a floating number: "))

print("Formatted number: {:.2f}".format(num))


